# Data Structures

*How to organize and structure data in Zig*


---
